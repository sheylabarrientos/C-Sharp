﻿namespace Loja.DTO
{
    public class ProdutoPesquisaDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Categoria { get; set; }
        public decimal PrecoUnitario { get; set; }
    }
}
