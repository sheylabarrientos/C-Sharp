﻿namespace Loja.DTO
{
    public class ProdutoParametrosPesquisaDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
    }
}
