﻿using System;

namespace DesafioExemploInterface
{
    public class Class1 : IClass1
    {
        //metodo
        public void irEmbora()
        {
            //vamos 
        }
    }
}
