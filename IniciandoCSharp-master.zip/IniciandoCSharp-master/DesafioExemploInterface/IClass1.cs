﻿namespace DesafioExemploInterface
{
    public interface IClass1
    {
        //metodo
        void irEmbora();
    }
}