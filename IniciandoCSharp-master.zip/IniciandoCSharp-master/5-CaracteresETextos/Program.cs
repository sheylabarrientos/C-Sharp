﻿using System;

namespace _5_CaracteresETextos
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando o projeto 5 - Caracteres e textos");

            // character
            char primeiraLetra = ' ';
            Console.WriteLine(primeiraLetra);

            primeiraLetra = (char)61;
            Console.WriteLine(primeiraLetra);

            primeiraLetra = (char)(primeiraLetra + 1);
            Console.WriteLine(primeiraLetra);

            string titulo = "Codenation Women Itau";
            string modulos =
@"Variáveis
Orientação Objeto
Clean Code";

            Console.WriteLine(titulo);
            Console.WriteLine(modulos);
            Console.ReadLine();
        }
    }
}
