﻿using System;

namespace PrimeiroProjeto
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Projeto no Visual Studio!");

            Console.ReadKey();
        }
    }
}
